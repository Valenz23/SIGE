library(testthat)
library(NoiseFiltersR)

test_check("NoiseFiltersR")
